
//linear_regression.hpp:

#ifndef NN_LINEAR_REGRESSION_HPP_
#define NN_LINEAR_REGRESSION_HPP_

#include <memory>
#include <string>
#include <ostream>

namespace ANN {

typedef enum {
	LEAST_SQUARES = 0,
	GRADIENT_DESCENT
} regression_method;

template<typename T>
class LinearRegression {
	template<typename U>
	friend std::ostream& operator << (std::ostream& out, const LinearRegression<U>& lr);

public:
	LinearRegression() = default;
	void set_regression_method(regression_method method);
	int init(const T* x, const T* y, int length);
	int train(const std::string& model, T learning_rate = 0, int iterations = 0);
	int load_model(const std::string& model) const;
	T predict(T x) const; // y = wx+b

private:
	int gradient_descent();
	int least_squares();
	int store_model() const;

	regression_method method;
	std::unique_ptr<T[]> x, y;
	std::string model = "";
	int iterations = 1000;
	int length = 0;
	T learning_rate = 0.001f;
	T weight = 0;
	T bias = 0;
};

} // namespace ANN

#endif // NN_LINEAR_REGRESSION_HPP_

/**************************************************************************************/

//linear_regression.cpp:

#include "linear_regression.hpp"
#include <fstream>
#include <random>
#include <algorithm>
#include <numeric>

namespace ANN {

template<typename T>
void LinearRegression<T>::set_regression_method(regression_method method)
{
	this->method = method;
}

template<typename T>
int LinearRegression<T>::init(const T* x, const T* y, int length)
{
	if (length < 3) {
		fprintf(stderr, "number of points must be greater than 2: %d\n", length);
		return -1;
	}

	this->x.reset(new T[length]);
	this->y.reset(new T[length]);

	for (int i = 0; i < length; ++i) {
		this->x[i] = x[i];
		this->y[i] = y[i];
	}

	this->length = length;

	return 0;
}

template<typename T>
int LinearRegression<T>::train(const std::string& model, T learning_rate, int iterations)
{
	this->learning_rate = learning_rate;
	this->iterations = iterations;
	this->model = model;

	if (this->method == LEAST_SQUARES) {
		least_squares();
	} else if (this->method == GRADIENT_DESCENT) {
		gradient_descent();
	} else {
		fprintf(stderr, "invalid linear regression method\n");
		return -1;
	}

	return store_model();
}

template<typename T>
int LinearRegression<T>::store_model() const
{
	std::ofstream file;
	file.open(model.c_str(), std::ios::binary);
	if (!file.is_open()) {
		fprintf(stderr, "open file fail: %s\n", model.c_str());
		return -1;
	}

	int m = method;
	file.write((char*)&m, sizeof(m));
	file.write((char*)&weight, sizeof(weight));
	file.write((char*)&bias, sizeof(bias));

	file.close();

	return 0;
}

template<typename T>
int LinearRegression<T>::load_model(const std::string& model) const
{
	std::ifstream file;
	file.open(model.c_str(), std::ios::binary);
	if (!file.is_open()) {
		fprintf(stderr, "open file fail: %s\n", model.c_str());
		return -1;
	}

	int m{ -1 };
	file.read((char*)&m, sizeof(m)* 1);
	file.read((char*)&weight, sizeof(weight)* 1);
	file.read((char*)&bias, sizeof(bias)* 1);

	file.close();

	return 0;
}

template<typename T>
T LinearRegression<T>::predict(T x) const
{
	return weight * x + bias;
}

template<typename T>
int LinearRegression<T>::gradient_descent()
{
	std::random_device rd; std::mt19937 generator(rd());
	std::uniform_real_distribution<T> distribution(0, 0.5);
	weight = distribution(generator);;
	bias = distribution(generator);;
	int count{ 0 };

	std::unique_ptr<T[]> error(new T[length]), error_x(new T[length]);

	for (int i = 0; i < iterations; ++i) {
		for (int j = 0; j < length; ++j) {
			error[j] = weight * x[j] + bias - y[j];
			error_x[j] = error[j] * x[j];
		}

		T error_ = std::accumulate(error.get(), error.get() + length, (T)0) / length;
		T error_x_ = std::accumulate(error_x.get(), error_x.get() + length, (T)0) / length;

		// error = p(i) - y(i)
		// bias(i+1) = bias(i) - learning_rate*error
		bias = bias - learning_rate * error_;
		// weight(i+1) = weight(i) - learning_rate*error*x
		weight = weight - learning_rate * error_x_;

		++count;
		if (count % 100 == 0)
			fprintf(stdout, "iteration %d\n", count);
	}

	return 0;
}

template<typename T>
int LinearRegression<T>::least_squares()
{
	T sum_x{ 0 }, sum_y{ 0 }, sum_x_squared{ 0 }, sum_xy{ 0 };

	for (int i = 0; i < length; ++i) {
		sum_x += x[i];
		sum_y += y[i];
		sum_x_squared += x[i] * x[i];
		sum_xy += x[i] * y[i];
	}

	if (fabs(length * sum_x_squared - sum_x * sum_x) > DBL_EPSILON) {
		weight = (length * sum_xy - sum_y * sum_x) / (length * sum_x_squared - sum_x * sum_x); // slope
		bias = (sum_x_squared * sum_y - sum_x * sum_xy) / (length * sum_x_squared - sum_x * sum_x); // intercept
	} else {
		weight = 0;
		bias = 0;
	}

	return 0;
}

template<typename T>
std::ostream& operator << (std::ostream& out, const LinearRegression<T>& lr)
{
	out << "result: y = " << lr.weight << "x + " << lr.bias;
	return out;
}

template std::ostream& operator << (std::ostream& out, const LinearRegression<float>& lr);
template std::ostream& operator << (std::ostream& out, const LinearRegression<double>& lr);
template class LinearRegression<float>;
template class LinearRegression<double>;

} // namespace ANN

/********************************************************************************************/

//funset.cpp:

#include "funset.hpp"
#include <iostream>
#include "perceptron.hpp"
#include "BP.hpp""
#include "CNN.hpp"
#include "linear_regression.hpp"
#include "common.hpp"
#include <opencv2/opencv.hpp>
int test_linear_regression_train()
{
	std::vector<float> x{6.2f, 9.5f, 10.5f, 7.7f, 8.6f, 6.9f, 7.3f, 2.2f, 5.7f, 2.f,
		2.5f, 4.f, 5.4f, 2.2f, 7.2f, 12.2f, 5.6f, 9.f, 3.6f, 5.f,
		11.3f, 3.4f, 11.9f, 10.5f, 10.7f, 10.8f, 4.8f};
	std::vector<float> y{ 29.f, 44.f, 36.f, 37.f, 53.f, 18.f, 31.f, 14.f, 11.f, 11.f,
		22.f, 16.f, 27.f, 9.f, 29.f, 46.f, 23.f, 39.f, 15.f, 32.f,
		34.f, 17.f, 46.f, 42.f, 43.f, 34.f, 19.f };
	CHECK(x.size() == y.size());
	ANN::LinearRegression<float> lr;
	lr.set_regression_method(ANN::GRADIENT_DESCENT);
	lr.init(x.data(), y.data(), x.size());
	float learning_rate{ 0.001f };
	int iterations{ 1000 };
	std::string model{ "E:/GitCode/NN_Test/data/linear_regression.model" };
	int ret = lr.train(model, learning_rate, iterations);
	if (ret != 0) {
		fprintf(stderr, "train fail\n");
		return -1;
	}
	std::cout << lr << std::endl; // y = wx + b
	return 0;
}
int test_linear_regression_predict()
{
	ANN::LinearRegression<float> lr;
	std::string model{ "E:/GitCode/NN_Test/data/linear_regression.model" };
	int ret = lr.load_model(model);
	if (ret != 0) {
		fprintf(stderr, "load model fail: %s\n", model.c_str());
		return -1;
	}
	float x = 13.8f;
	float result = lr.predict(x);
	fprintf(stdout, "input value: %f, result value: %f\n", x, result);
	return 0;
}

